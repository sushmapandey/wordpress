# Gutenberg theme
This theme is designed to showcase what Gutenberg can do with regards to themes. It is intended as a work in progress, at least until v1 of the new editor (and maybe beyond).

# Block focused
If something isn't a block yet, this theme will not have it. As each block happens, the theme will gain that functionality.

# Styling just like Gutenberg
The idea of the default look for this theme is to as closely replicate that of the Gutenberg editor output as possible. As a result the focus is on that styling not creating a new look.. yet. As things grow, we may have styles and go further into what the theme can have... who knows.
